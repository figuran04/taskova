package model;

public class Notification {

    public static void showNotification(String message) {
        System.out.println("Notification: " + message);
    }
}
